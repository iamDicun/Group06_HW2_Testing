# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: login.spec.ts >> FR-02: Feature Testing - Đăng nhập >> [TC-LOG-010] - Nhập chuỗi SQL Injection vào ô email
- Location: tests\login.spec.ts:7:9

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: /đăng nhập|login/i })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('button', { name: /đăng nhập|login/i })

```

```yaml
- banner:
  - link "EShop":
    - /url: /
  - navigation:
    - link "Giỏ hàng":
      - /url: /cart
    - link "Đăng nhập":
      - /url: /login
    - link "Đăng ký":
      - /url: /register
- main:
  - heading "Đăng Ký" [level=2]
  - text: Username
  - textbox
  - text: Mật khẩu
  - textbox
  - link "Quên mật khẩu?":
    - /url: /forgot-password
  - button "Sign In"
  - text: Chưa có tài khoản?
  - link "Đăng ký ngay":
    - /url: /register
- contentinfo: © 2026 EShop SUT. Dành cho mục đích kiểm thử.
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import loginData from '../test-data/login-data.json';
  3  | 
  4  | test.describe('FR-02: Feature Testing - Đăng nhập', () => {
  5  | 
  6  |   loginData.forEach((data) => {
  7  |     test(`[${data.id}] - ${data.description}`, async ({ page }) => {
  8  |       // 1. Điều hướng tới trang Đăng nhập
  9  |       await page.goto('http://localhost:5173/login');
  10 | 
  11 |       // Khởi tạo các locator
  12 |       const emailInput = page.getByLabel(/email/i).or(page.locator('input[type="email"]'));
  13 |       const passwordInput = page.getByLabel(/mật khẩu|password/i).or(page.locator('input[type="password"]'));
  14 |       const submitButton = page.getByRole('button', { name: /đăng nhập|login/i });
  15 | 
  16 |       // [Pattern 1]: Assertion kiểm tra nút bấm/input hiển thị trên UI
> 17 |       await expect(submitButton).toBeVisible();
     |                                  ^ Error: expect(locator).toBeVisible() failed
  18 | 
  19 |       // 2. Nhập thông tin test data
  20 |       if (data.email) await emailInput.fill(data.email);
  21 |       if (data.password) await passwordInput.fill(data.password);
  22 | 
  23 |       // 3. Bấm đăng nhập
  24 |       await submitButton.click();
  25 | 
  26 |       // 4. Kiểm tra kết quả mong đợi (Data-Driven Assertions)
  27 |       if (data.expectedStatus === 'success') {
  28 |         // [Pattern 2]: Assertion kiểm tra URL chuyển hướng sau đăng nhập
  29 |         await expect(page).toHaveURL(new RegExp(data.expectedUrl));
  30 |       } else {
  31 |         // [Pattern 3]: Assertion kiểm tra thông báo lỗi hiển thị
  32 |         const errorMessage = page.locator('.error-message, [role="alert"], .toast');
  33 |         await expect(errorMessage).toContainText(new RegExp(data.expectedMessage, 'i'));
  34 |       }
  35 |     });
  36 |   });
  37 | 
  38 | });
```