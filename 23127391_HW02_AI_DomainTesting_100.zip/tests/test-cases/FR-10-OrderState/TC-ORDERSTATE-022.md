# TC-ORDERSTATE-022: Người dùng hủy đơn hàng của chính mình ở trạng thái confirmed thành công (Domain Testing)

## Requirement ID
FR-10

## Feature
Trạng thái Đơn hàng

## Module / Test Type / Technique
OrderState / Functional / Equivalence Partitioning

## Priority
High

## Preconditions
- Đơn hàng có ID = 11 tồn tại trong CSDL và thuộc sở hữu của người dùng có ID = 42.
- Trạng thái hiện tại của đơn hàng là "confirmed".
- Người dùng ID = 42 đã đăng nhập và có token xác thực hợp lệ.

## Test Data
| Field | Value |
|---|---|
| id (URL Path) | 11 |
| token_user_id (Token Claim) | 42 |
| order_user_id (DB) | 42 |

## Test Steps
1. Gửi request PUT /api/orders/11/cancel với header Authorization chứa token của User ID = 42.
2. Kiểm tra phản hồi từ API và trạng thái trong CSDL.

## Expected Result
- Mã phản hồi HTTP trả về là 200 OK.
- Nội dung phản hồi xác nhận hủy đơn hàng thành công.
- Trạng thái đơn hàng ID = 11 trong CSDL chuyển thành "canceled".

## Actual Result (filled after execution)
- API trả về mã phản hồi HTTP 200.
- Trạng thái đơn hàng trong cơ sở dữ liệu là 'canceled'.
- Thông báo phản hồi: 'Order canceled successfully'.

## Status
PASSED

## Related Bugs
None

## Notes
- Luồng hủy đơn hàng hợp lệ: User tự hủy đơn hàng của mình khi đã confirmed.
